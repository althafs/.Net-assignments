﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace ADO_NET_PROJECT.model
{

    class EmployeeLogic
    {
        private string connStr = ConfigurationManager.ConnectionStrings["db5"].ConnectionString;

        public DataSet getEmpDetails()
        {
            SqlConnection conn = new SqlConnection(connStr);

            string query = "select * from Employee";
            DataSet ds = new DataSet();

            try
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(ds);
                MessageBox.Show("Data Retrieved Successfully..");

            }
            catch (Exception)
            {
                MessageBox.Show("Failed to Connect DB..!!");
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        //INSERT INTO EMPLOYEE DETAILS FUNCTION
        public string insertEmp(Employee e)
        {

            string msg = null;

            SqlConnection conn = new SqlConnection(connStr);

            string proc1 = "EMP_INSERT";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(proc1, conn);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EMPID", SqlDbType.Int).Value = e.EmpId;
                cmd.Parameters.Add("@EMPNAME", SqlDbType.VarChar, 50).Value = e.EmpName;
                cmd.Parameters.Add("@DOB", SqlDbType.DateTime).Value = e.Dob;
                cmd.Parameters.Add("@PHONE", SqlDbType.VarChar, 50).Value = e.Phone;
                cmd.Parameters.Add("@MAIL", SqlDbType.VarChar, 50).Value = e.Mail;
                cmd.Parameters.Add("@SALARY", SqlDbType.Float).Value = e.Salary;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = e.DeptId;

                cmd.ExecuteNonQuery();

                msg = "Data Inserted Successfully...";

            }
            catch (Exception)
            {
                msg = "Procedure not Executed DB..!!";
            }

            finally
            {
                conn.Close();
            }

            return msg;
        }

        //GET EMPLOYEE DATA BY NAME FUNCTION
        public DataSet getEmpDataByName(string name)
        {

            SqlConnection conn = new SqlConnection(connStr);

            string query = "select * from Employee where empname='" + name + "'";
            DataSet ds = new DataSet();

            try
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(ds);

                MessageBox.Show("Data Inserted Successfully...");

            }
            catch (Exception)
            {
                MessageBox.Show("Failed to Connect DB..!!");
            }
            finally
            {
                conn.Close();
            }
            return ds;

        }

        //GET EMPLOYEE DATA BY SALARY FUNCTION
        public DataSet getEmpDataBySalary(float salary)
        {

            SqlConnection conn = new SqlConnection(connStr);
            string query = "select * from Employee where salary=" + salary;

            DataSet ds = new DataSet();

            try
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(ds);

                MessageBox.Show("Data Inserted Successfully...");

            }
            catch (Exception)
            {
                MessageBox.Show("Failed to Connect DB..!!");
            }
            finally
            {
                conn.Close();
            }
            return ds;

        }

        //FIND EMPLOYEE DATA BY ID FUNCTION
        public Employee findDataById(int id)
        {

            SqlConnection conn = new SqlConnection(connStr);
            string query = "select * from Employee where EMPID=" + id;
            Employee e2 = new Employee();

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {

                    while(reader.Read())
                    {
                        e2.EmpId = Convert.ToInt32(reader.GetValue(0));
                        e2.EmpName = reader.GetValue(1).ToString();
                        e2.Dob = Convert.ToDateTime(reader.GetValue(2));
                        e2.Phone = reader.GetValue(3).ToString();
                        e2.Mail = reader.GetValue(4).ToString();
                        e2.Salary =float.Parse(reader.GetValue(5).ToString());
                        e2.DeptId = Convert.ToInt32(reader.GetValue(6));

                    }
                  
                }
                else
                {
                    e2 = null;
                   
                }
          

            }
            catch (Exception)
            {
                MessageBox.Show("Failed to Connect DB..!!");
            }
            finally
            {
                conn.Close();
            }
            return e2;

        }

        //UPDATE EMLOYEE RECORD FUNCTION
        public string updateRecord(Employee e)
        {

            string msg = null;
            SqlConnection conn = new SqlConnection(connStr);

            string proc1 = "EMP_UPDATE";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(proc1, conn);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EMPID", SqlDbType.Int).Value = e.EmpId;
                cmd.Parameters.Add("@EMPNAME", SqlDbType.VarChar, 50).Value = e.EmpName;
                cmd.Parameters.Add("@DOB", SqlDbType.DateTime).Value = e.Dob;
                cmd.Parameters.Add("@PHONE", SqlDbType.VarChar, 50).Value = e.Phone;
                cmd.Parameters.Add("@MAIL", SqlDbType.VarChar, 50).Value = e.Mail;
                cmd.Parameters.Add("@SALARY", SqlDbType.Float).Value = e.Salary;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = e.DeptId;


                cmd.ExecuteNonQuery();

                msg = "data updated";

            }
            catch (Exception)
            {
                msg = "Procedure not Executed!! ";
            }

            finally
            {
                conn.Close();
            }

            return msg;
        }

        //DELETE RECORD BY ID FUNCTION
        public string deleteRecordById(int id)
        {

            string msg = null;

            SqlConnection conn = new SqlConnection(connStr);

            string proc1 = "EMP_DELETE";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(proc1, conn);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EMPID", SqlDbType.Int).Value = id;
               

                cmd.ExecuteNonQuery();

                msg = "RECORD DELETED";

            }
            catch (Exception)
            {
                msg = "Procedure not Executed!! ";
            }

            finally
            {
                conn.Close();
            }

            return msg;
        }










    }
}
