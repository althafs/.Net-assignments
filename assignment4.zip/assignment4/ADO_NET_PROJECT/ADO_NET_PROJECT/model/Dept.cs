﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_NET_PROJECT.model
{
    class Dept
    {

        public int DeptId { get; set; }
        public string DeptName { get; set; }
        public string DeptLoc { get; set; }
        public int MgrId { get; set; }

    }
}
